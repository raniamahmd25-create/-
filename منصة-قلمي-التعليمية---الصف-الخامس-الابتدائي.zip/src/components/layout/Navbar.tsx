import React from 'react';
import { 
  BookOpen, 
  Moon, 
  Sun, 
  Plus, 
  PenTool, 
  Layers, 
  GraduationCap,
  Bell
} from 'lucide-react';

interface NavbarProps {
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenPublishModal: () => void;
  onOpenRemindersModal: () => void;
  totalDocsCount: number;
  activeRemindersCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  darkMode,
  onToggleDarkMode,
  onOpenPublishModal,
  onOpenRemindersModal,
  totalDocsCount,
  activeRemindersCount = 0,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 font-['Cairo',sans-serif]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Name with 5th Grade Badge */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-slate-950 flex items-center justify-center shadow-md">
              <PenTool className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-lg text-slate-900 dark:text-white tracking-tight">
                  منصة <span className="text-amber-500">قلمي</span>
                </span>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-amber-500/15 dark:bg-amber-400/20 text-amber-800 dark:text-amber-300 font-black border border-amber-300 dark:border-amber-700/60 flex items-center gap-1">
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span>الصف الخامس الابتدائي</span>
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 hidden sm:block">
                مكتبة المذكرات والكتب والملازم مع القلم الإلكتروني الذكي
              </p>
            </div>
          </div>

          {/* Quick Stats & Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Total Docs Badge */}
            <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-300 border border-slate-200/60 dark:border-slate-700/60">
              <Layers className="w-3.5 h-3.5 text-amber-500" />
              <span>{totalDocsCount} مذكرات محفوظة</span>
            </div>

            {/* Study Reminders Button (تنبيهات ومواعيد المذاكرة) */}
            <button
              type="button"
              onClick={onOpenRemindersModal}
              className="relative flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/50 dark:hover:bg-amber-900/60 text-amber-900 dark:text-amber-300 rounded-xl text-xs font-black border border-amber-200 dark:border-amber-800 transition active:scale-95 shadow-xs"
              title="تنبيهات ومواعيد مراجعة المواد الدراسية"
            >
              <Bell className="w-4 h-4 text-amber-600 dark:text-amber-400 fill-amber-500" />
              <span className="hidden sm:inline">تنبيهات المذاكرة</span>
              {activeRemindersCount > 0 && (
                <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 font-black text-[10px] flex items-center justify-center shadow-xs">
                  {activeRemindersCount}
                </span>
              )}
            </button>

            {/* Morning Mode / Night Mode Switcher (وضع صباح / وضع ليل) */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => {
                  if (darkMode) onToggleDarkMode();
                }}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-black transition-all ${
                  !darkMode
                    ? 'bg-amber-400 text-slate-950 shadow-xs'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
                title="تفعيل الوضع الصباحي المشرق"
              >
                <Sun className="w-4 h-4 text-amber-800 fill-amber-500" />
                <span>وضع صباح</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (!darkMode) onToggleDarkMode();
                }}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-black transition-all ${
                  darkMode
                    ? 'bg-slate-900 text-amber-300 shadow-xs'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
                title="تفعيل الوضع المسائي المظلم"
              >
                <Moon className="w-4 h-4 text-indigo-400 fill-indigo-400" />
                <span>وضع ليل</span>
              </button>
            </div>

            {/* Publish Button */}
            <button
              type="button"
              onClick={onOpenPublishModal}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 text-xs sm:text-sm font-black shadow-md transition flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>نشر جديد</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
