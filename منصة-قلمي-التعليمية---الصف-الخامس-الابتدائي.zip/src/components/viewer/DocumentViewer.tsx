import React, { useState, useEffect, useCallback } from 'react';
import { StudyDocument, ToolMode, AnnotationItem, SUBJECTS } from '../../types';
import { InteractiveCanvas } from './InteractiveCanvas';
import { MovablePenToolbar } from './MovablePenToolbar';
import { StorageService } from '../../services/storage';
import { createBlankPage } from '../../services/fileProcessor';
import { 
  ArrowRight, 
  ChevronRight, 
  ChevronLeft, 
  Download, 
  FileText, 
  Image as ImageIcon, 
  Plus, 
  X, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Star, 
  Printer, 
  LayoutGrid, 
  Maximize2,
  Bookmark,
  Share2,
  Sun,
  Moon,
  Trash2,
  Focus,
  Eye,
  EyeOff,
  BrainCircuit,
  Bell
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { AiTutorSidebar } from './AiTutorSidebar';

interface DocumentViewerProps {
  initialDocument: StudyDocument;
  openDocuments: StudyDocument[];
  activeDocId: string;
  onSelectDocument: (docId: string) => void;
  onCloseDocument: (docId: string) => void;
  onBackToLibrary: () => void;
  onOpenPublishModal: () => void;
  onDeleteDocument: (docId: string) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenReminderForDoc?: (doc: StudyDocument) => void;
}

export const DocumentViewer: React.FC<DocumentViewerProps> = ({
  initialDocument,
  openDocuments,
  activeDocId,
  onSelectDocument,
  onCloseDocument,
  onBackToLibrary,
  onOpenPublishModal,
  onDeleteDocument,
  darkMode,
  onToggleDarkMode,
  onOpenReminderForDoc,
}) => {
  const [currentDoc, setCurrentDoc] = useState<StudyDocument>(initialDocument);
  const [currentPageIndex, setCurrentPageIndex] = useState<number>(0);
  
  // Pen and Drawing Tools State
  const [currentTool, setCurrentTool] = useState<ToolMode>('pen');
  const [currentColor, setCurrentColor] = useState<string>('#dc2626'); // Red by default like teacher correction
  const [strokeWidth, setStrokeWidth] = useState<number>(3);
  const [fontSize, setFontSize] = useState<number>(18);
  const [isBold, setIsBold] = useState<boolean>(true);
  const [zoom, setZoom] = useState<number>(1.0);
  const [showThumbnails, setShowThumbnails] = useState<boolean>(false);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [isAutoSaved, setIsAutoSaved] = useState<boolean>(true);
  const [showExportMenu, setShowExportMenu] = useState<boolean>(false);

  // Undo / Redo stacks per page
  const [undoStack, setUndoStack] = useState<AnnotationItem[][]>([]);
  const [redoStack, setRedoStack] = useState<AnnotationItem[][]>([]);

  // Focus Mode State (وضع التركيز بدون تشتيت)
  const [focusMode, setFocusMode] = useState<boolean>(false);

  // AI Tutor State (المعلم الذكي بجانب المذكرة - يفتح تلقائياً لتسهيل السؤال)
  const [showAiTutor, setShowAiTutor] = useState<boolean>(true);

  // Keyboard shortcut to exit focus mode
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && focusMode) {
        setFocusMode(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [focusMode]);

  // Sync when initialDocument changes
  useEffect(() => {
    setCurrentDoc(initialDocument);
    setCurrentPageIndex(0);
    setUndoStack([]);
    setRedoStack([]);
  }, [initialDocument.id]);

  const activePage = currentDoc.pages[currentPageIndex] || currentDoc.pages[0];
  const subjectInfo = SUBJECTS.find((s) => s.id === currentDoc.subject) || SUBJECTS[0];

  // Auto-Save handler
  const handleSaveAnnotations = useCallback(
    (newAnnotations: AnnotationItem[]) => {
      setIsAutoSaved(false);
      
      const updatedPages = [...currentDoc.pages];
      if (updatedPages[currentPageIndex]) {
        updatedPages[currentPageIndex] = {
          ...updatedPages[currentPageIndex],
          annotations: newAnnotations,
          lastEdited: Date.now(),
        };
      }

      const updatedDoc: StudyDocument = {
        ...currentDoc,
        pages: updatedPages,
        updatedAt: new Date().toISOString(),
      };

      setCurrentDoc(updatedDoc);
      StorageService.saveDocument(updatedDoc);

      // Flash auto-saved status after short debounce
      setTimeout(() => {
        setIsAutoSaved(true);
      }, 400);
    },
    [currentDoc, currentPageIndex]
  );

  const handleClearPage = () => {
    setUndoStack((prev) => [...prev, activePage.annotations || []]);
    setRedoStack([]);
    handleSaveAnnotations([]);
  };

  const handleAddBlankPage = () => {
    const newPage = createBlankPage(currentDoc.pages.length + 1, 'lined');
    const updatedDoc = {
      ...currentDoc,
      pages: [...currentDoc.pages, newPage],
    };
    setCurrentDoc(updatedDoc);
    StorageService.saveDocument(updatedDoc);
    setCurrentPageIndex(currentDoc.pages.length);
  };

  const handleExportPdf = async () => {
    try {
      setIsExporting(true);
      await StorageService.exportAnnotatedPdf(currentDoc);
      confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
    } catch (e) {
      console.error(e);
      alert('حدث خطأ أثناء تصدير ملف PDF، يرجى المحاولة مرة أخرى.');
    } finally {
      setIsExporting(false);
      setShowExportMenu(false);
    }
  };

  const handleExportCurrentPage = async () => {
    try {
      setIsExporting(true);
      await StorageService.exportPageAsImage(activePage, currentDoc.title);
    } catch (e) {
      console.error(e);
    } finally {
      setIsExporting(false);
      setShowExportMenu(false);
    }
  };

  const toggleBookmark = () => {
    const currentBookmarks = currentDoc.bookmarks || [];
    const isBookmarked = currentBookmarks.includes(activePage.pageNumber);
    const updated = isBookmarked
      ? currentBookmarks.filter((p) => p !== activePage.pageNumber)
      : [...currentBookmarks, activePage.pageNumber];

    const updatedDoc = { ...currentDoc, bookmarks: updated };
    setCurrentDoc(updatedDoc);
    StorageService.saveDocument(updatedDoc);
  };

  return (
    <div className="flex flex-col h-screen bg-slate-100 dark:bg-slate-950 overflow-hidden font-['Cairo',sans-serif] relative">
      {/* 1. Google Chrome-Style Document Tabs Bar (مخفي في وضع التركيز) */}
      {!focusMode && (
        <div className="bg-slate-200 dark:bg-slate-900 border-b border-slate-300 dark:border-slate-800 pt-1.5 px-2 flex items-center gap-1 overflow-x-auto select-none no-scrollbar">
        {/* Back to Library Button */}
        <button
          type="button"
          onClick={onBackToLibrary}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-800 transition mr-1"
          title="الرجوع إلى المكتبة الرئيسية"
        >
          <ArrowRight className="w-4 h-4" />
          <span>المكتبة</span>
        </button>

        <div className="h-4 w-px bg-slate-300 dark:bg-slate-700 mx-1" />

        {/* Browser Tabs List */}
        {openDocuments.map((doc) => {
          const isActive = doc.id === currentDoc.id;
          const sInfo = SUBJECTS.find((s) => s.id === doc.subject);
          return (
            <div
              key={doc.id}
              onClick={() => {
                if (!isActive) onSelectDocument(doc.id);
              }}
              className={`group relative flex items-center gap-2 max-w-[220px] min-w-[140px] px-3 py-2 rounded-t-xl text-xs font-bold cursor-pointer transition-all border-t border-x ${
                isActive
                  ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-white border-slate-300 dark:border-slate-800 shadow-sm z-10'
                  : 'bg-slate-200/80 dark:bg-slate-900/60 text-slate-600 dark:text-slate-400 border-transparent hover:bg-slate-300/80 dark:hover:bg-slate-800'
              }`}
            >
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0"
                style={{ backgroundColor: sInfo?.bgLight ? undefined : '#0284c7' }}
              />
              <span className="truncate flex-1 text-right">{doc.title}</span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onCloseDocument(doc.id);
                }}
                className="opacity-0 group-hover:opacity-100 p-0.5 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition"
                title="إغلاق هذا المستند"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}

        {/* Add New / Publish Document Tab Button */}
        <button
          type="button"
          onClick={onOpenPublishModal}
          className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-300/70 dark:hover:bg-slate-800 transition"
          title="نشر أو فتح مستند جديد (+)"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>
      )}

      {/* 2. Secondary Navigation & Actions Bar (مخفي في وضع التركيز) */}
      {!focusMode && (
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 py-2 flex flex-wrap items-center justify-between gap-3 shadow-xs">
        {/* Document Metadata & Bookmark */}
        <div className="flex items-center gap-3">
          <span className={`text-xs px-2.5 py-1 rounded-full font-bold border ${subjectInfo.badgeColor}`}>
            {subjectInfo.nameAr}
          </span>
          <h1 className="text-sm md:text-base font-extrabold text-slate-900 dark:text-white truncate max-w-[280px] md:max-w-md">
            {currentDoc.title}
          </h1>
          <button
            type="button"
            onClick={toggleBookmark}
            className={`p-1 rounded-lg transition ${
              currentDoc.bookmarks?.includes(activePage.pageNumber)
                ? 'text-amber-500 hover:text-amber-600'
                : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
            }`}
            title="حفظ إشارة مرجعية لهذه الصفحة"
          >
            <Bookmark className="w-4 h-4 fill-current" />
          </button>
        </div>

        {/* Page Switcher & Google-like Page Tabs */}
        <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
          <button
            type="button"
            onClick={() => setCurrentPageIndex((prev) => Math.max(0, prev - 1))}
            disabled={currentPageIndex === 0}
            className="p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-transparent text-slate-700 dark:text-slate-200 transition"
            title="الصفحة السابقة"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-1 px-2 text-xs font-bold text-slate-700 dark:text-slate-300">
            <span>صفحة</span>
            <span className="text-amber-600 dark:text-amber-400 font-extrabold">{currentPageIndex + 1}</span>
            <span>من</span>
            <span>{currentDoc.pages.length}</span>
          </div>

          <button
            type="button"
            onClick={() => setCurrentPageIndex((prev) => Math.min(currentDoc.pages.length - 1, prev + 1))}
            disabled={currentPageIndex >= currentDoc.pages.length - 1}
            className="p-1.5 rounded-lg hover:bg-white dark:hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-transparent text-slate-700 dark:text-slate-200 transition"
            title="الصفحة التالية"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Toggle Thumbnails drawer */}
          <button
            type="button"
            onClick={() => setShowThumbnails(!showThumbnails)}
            className={`p-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
              showThumbnails
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'hover:bg-white dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300'
            }`}
            title="عرض فهرس الصفحات والشرائح المصغرة"
          >
            <LayoutGrid className="w-4 h-4" />
            <span className="hidden sm:inline">الفهرس</span>
          </button>

          {/* Add blank lined page */}
          <button
            type="button"
            onClick={handleAddBlankPage}
            className="p-1.5 rounded-lg text-xs font-bold hover:bg-white dark:hover:bg-slate-700 text-emerald-600 dark:text-emerald-400 transition flex items-center gap-1"
            title="إضافة صفحة كشكول مسطرة للملاحظات"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">صفحة جديدة</span>
          </button>
        </div>

        {/* Zoom & Export Actions */}
        <div className="flex items-center gap-2">
          {/* Zoom controls */}
          <div className="hidden lg:flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs">
            <button
              type="button"
              onClick={() => setZoom((z) => Math.max(0.6, z - 0.1))}
              className="p-1 rounded hover:bg-white dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
              title="تصغير"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="px-1.5 font-mono text-[11px] font-bold text-slate-600 dark:text-slate-300">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() => setZoom((z) => Math.min(2.0, z + 0.1))}
              className="p-1 rounded hover:bg-white dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
              title="تكبير"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setZoom(1.0)}
              className="p-1 rounded hover:bg-white dark:hover:bg-slate-700 text-slate-500"
              title="إعادة ضبط 100%"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>

          {/* Direct 'تصدير كـ PDF' Button in Toolbar (تصدير كـ PDF لتحميل المذكرة بعد الملاحظات) */}
          <button
            type="button"
            onClick={handleExportPdf}
            disabled={isExporting}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white rounded-xl text-xs font-black shadow-md hover:shadow-lg transition-all active:scale-95 disabled:opacity-50"
            title="تصدير كـ PDF - تحميل المذكرة بعد إضافة ملاحظاتك وحلولك عليها"
          >
            {isExporting ? (
              <>
                <span className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                <span>جاري إنشاء PDF...</span>
              </>
            ) : (
              <>
                <FileText className="w-4 h-4 text-white" />
                <span>تصدير كـ PDF</span>
              </>
            )}
          </button>

          {/* Secondary Export Options Menu (صورة PNG / طباعة) */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowExportMenu(!showExportMenu)}
              className="p-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-xs transition"
              title="خيارات تصدير إضافية (صورة PNG / طباعة مباشرة)"
            >
              <Download className="w-4 h-4" />
            </button>

            {showExportMenu && (
              <div className="absolute left-0 top-full mt-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-2 z-50 w-56 flex flex-col gap-1">
                <div className="text-[11px] font-bold text-slate-400 px-2 py-1">خيارات التصدير:</div>
                <button
                  type="button"
                  onClick={handleExportPdf}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-right w-full"
                >
                  <FileText className="w-4 h-4 text-rose-500" />
                  <div>
                    <div>تصدير كـ PDF كامل</div>
                    <div className="text-[10px] text-slate-400 font-normal">مع الملاحظات والرسومات والحلول</div>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={handleExportCurrentPage}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-right w-full"
                >
                  <ImageIcon className="w-4 h-4 text-blue-500" />
                  <div>
                    <div>تصدير الصفحة الحالية (صورة PNG)</div>
                    <div className="text-[10px] text-slate-400 font-normal">صورة عالية الدقة للمشاركة السريعة</div>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    window.print();
                    setShowExportMenu(false);
                  }}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-right w-full"
                >
                  <Printer className="w-4 h-4 text-purple-500" />
                  <div>طباعة المستند مباشر</div>
                </button>
              </div>
            )}
          </div>

          {/* Morning Mode / Night Mode Switcher (وضع صباح / وضع ليل) */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={() => {
                if (darkMode) onToggleDarkMode();
              }}
              className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold transition-all ${
                !darkMode
                  ? 'bg-amber-400 text-slate-950 shadow-xs font-black'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
              title="تفعيل وضع الصباح المشرق"
            >
              <Sun className="w-3.5 h-3.5 text-amber-800 fill-amber-500" />
              <span className="hidden sm:inline">صباح</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (!darkMode) onToggleDarkMode();
              }}
              className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold transition-all ${
                darkMode
                  ? 'bg-slate-900 text-amber-300 shadow-xs font-black'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
              title="تفعيل وضع الليل المظلم"
            >
              <Moon className="w-3.5 h-3.5 text-indigo-400 fill-indigo-400" />
              <span className="hidden sm:inline">ليل</span>
            </button>
          </div>

          {/* AI Mode Button (المعلم الذكي AI بجانب المذكرة) */}
          <button
            type="button"
            onClick={() => setShowAiTutor(!showAiTutor)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black shadow-xs transition-all ${
              showAiTutor
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white ring-2 ring-indigo-400 shadow-md'
                : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 dark:text-indigo-300'
            }`}
            title="تفعيل أو إخفاء وضع المعلم الذكي AI بجانب المذكرة"
          >
            <BrainCircuit className="w-4 h-4 text-amber-300 animate-pulse" />
            <span>المعلم الذكي AI</span>
            {showAiTutor && <span className="w-2 h-2 rounded-full bg-emerald-400" />}
          </button>

          {/* Study Reminder Button (تنبيه مراجعة المذكرة) */}
          {onOpenReminderForDoc && (
            <button
              type="button"
              onClick={() => onOpenReminderForDoc(currentDoc)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:hover:bg-amber-900/60 dark:text-amber-300 rounded-xl text-xs font-black shadow-xs transition border border-amber-200/80 dark:border-amber-800/80"
              title="ضبط تنبيه وتذكير لمراجعة هذه المذكرة لاحقاً"
            >
              <Bell className="w-3.5 h-3.5 fill-amber-500 text-amber-600 dark:text-amber-400" />
              <span className="hidden sm:inline">تذكير مراجعة</span>
            </button>
          )}

          {/* Focus Mode Button (وضع التركيز لمذاكرة هادئة بدون تشتيت) */}
          <button
            type="button"
            onClick={() => {
              setFocusMode(true);
              setShowThumbnails(false);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-600 text-indigo-700 hover:text-white dark:bg-indigo-950/60 dark:hover:bg-indigo-600 dark:text-indigo-300 rounded-xl text-xs font-black shadow-xs transition"
            title="تفعيل وضع التركيز لإخفاء جميع القوائم والأدوات الجانبية والتركيز على محتوى المذكرة فقط"
          >
            <Focus className="w-4 h-4" />
            <span>وضع التركيز</span>
          </button>

          {/* Instant Delete Document Button (مسح المذكرة فوراً) */}
          <button
            type="button"
            onClick={() => {
              onDeleteDocument(currentDoc.id);
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white dark:bg-rose-950/60 dark:hover:bg-rose-600 rounded-xl text-xs font-bold transition"
            title="مسح هذه المذكرة فوراً وحذفها"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>مسح المذكرة</span>
          </button>
        </div>
      </div>
      )}

      {/* Floating Focus Mode Bar (يظهر فقط في وضع التركيز) */}
      {focusMode && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-4 py-2 rounded-2xl shadow-2xl border border-indigo-200 dark:border-indigo-900/80 animate-in fade-in slide-in-from-top-2 duration-200 select-none">
          <div className="flex items-center gap-1.5 text-xs font-black text-indigo-600 dark:text-indigo-400">
            <Focus className="w-4 h-4 animate-pulse" />
            <span>وضع التركيز نشط</span>
          </div>

          <div className="h-4 w-px bg-slate-200 dark:bg-slate-700" />

          {/* Quick Page Flip in Focus Mode */}
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300">
            <button
              type="button"
              onClick={() => setCurrentPageIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentPageIndex === 0}
              className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30"
              title="الصفحة السابقة"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <span className="font-mono text-xs">
              صفحة {currentPageIndex + 1} من {currentDoc.pages.length}
            </span>
            <button
              type="button"
              onClick={() => setCurrentPageIndex((prev) => Math.min(currentDoc.pages.length - 1, prev + 1))}
              disabled={currentPageIndex >= currentDoc.pages.length - 1}
              className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30"
              title="الصفحة التالية"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          <div className="h-4 w-px bg-slate-200 dark:bg-slate-700" />

          {/* Zoom In/Out in Focus Mode */}
          <div className="flex items-center gap-1 text-xs">
            <button
              type="button"
              onClick={() => setZoom((z) => Math.max(0.6, z - 0.1))}
              className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
              title="تصغير"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="font-mono text-[11px] font-bold text-slate-600 dark:text-slate-300">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() => setZoom((z) => Math.min(2.0, z + 0.1))}
              className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
              title="تكبير"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-4 w-px bg-slate-200 dark:bg-slate-700" />

          {/* Export PDF Button in Focus Mode */}
          <button
            type="button"
            onClick={handleExportPdf}
            disabled={isExporting}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-sm transition active:scale-95 disabled:opacity-50"
            title="تصدير كـ PDF مع ملاحظاتك وحلولك"
          >
            {isExporting ? (
              <span className="w-3 h-3 border-2 border-white/40 border-t-white rounded-full animate-spin" />
            ) : (
              <FileText className="w-3.5 h-3.5" />
            )}
            <span>تصدير كـ PDF</span>
          </button>

          <div className="h-4 w-px bg-slate-200 dark:bg-slate-700" />

          {/* Exit Focus Mode Button */}
          <button
            type="button"
            onClick={() => setFocusMode(false)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-extrabold shadow-sm transition"
            title="الخروج من وضع التركيز وإظهار جميع القوائم والأدوات (Esc)"
          >
            <EyeOff className="w-3.5 h-3.5" />
            <span>إنهاء وضع التركيز (Esc)</span>
          </button>
        </div>
      )}

      {/* 3. Main Workspace Area: Sidebar (Thumbnails) + Canvas */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Thumbnails Sidebar */}
        {!focusMode && showThumbnails && (
          <div className="w-60 bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 flex flex-col p-3 overflow-y-auto z-30 shadow-lg">
            <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-100 dark:border-slate-800">
              <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
                صفحات المستند ({currentDoc.pages.length})
              </span>
              <button
                type="button"
                onClick={() => setShowThumbnails(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 gap-3">
              {currentDoc.pages.map((p, index) => (
                <div
                  key={p.id}
                  onClick={() => setCurrentPageIndex(index)}
                  className={`group relative rounded-xl border-2 overflow-hidden cursor-pointer p-1 transition-all ${
                    currentPageIndex === index
                      ? 'border-amber-500 shadow-md ring-2 ring-amber-400/30'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-400'
                  }`}
                >
                  <img
                    src={p.imageUrl}
                    alt={`صفحة ${p.pageNumber}`}
                    className="w-full h-auto rounded bg-slate-50 dark:bg-slate-950 object-cover"
                  />
                  <div className="flex items-center justify-between mt-1 px-1 text-[11px] font-bold text-slate-600 dark:text-slate-300">
                    <span>صفحة {p.pageNumber}</span>
                    {p.annotations?.length > 0 && (
                      <span className="text-[10px] text-amber-600 dark:text-amber-400">
                        ({p.annotations.length} ملاحظة)
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Interactive Drawing & Reading Surface */}
        <div className="flex-1 overflow-auto bg-slate-100 dark:bg-slate-950/80 flex items-start justify-center p-4">
          <InteractiveCanvas
            page={activePage}
            currentTool={currentTool}
            currentColor={currentColor}
            strokeWidth={strokeWidth}
            fontSize={fontSize}
            isBold={isBold}
            zoom={zoom}
            onSaveAnnotations={handleSaveAnnotations}
            undoStack={undoStack}
            redoStack={redoStack}
            setUndoStack={setUndoStack}
            setRedoStack={setRedoStack}
          />
        </div>

        {/* AI Tutor Assistant Panel Beside Note (وضع AI جانب المذكرة) */}
        {!focusMode && showAiTutor && (
          <AiTutorSidebar
            isOpen={showAiTutor}
            onClose={() => setShowAiTutor(false)}
            document={currentDoc}
            currentPage={activePage}
          />
        )}

        {/* Movable Floating Electronic Pen Toolbar (مخفي في وضع التركيز) */}
        {!focusMode && (
          <MovablePenToolbar
          currentTool={currentTool}
          setCurrentTool={setCurrentTool}
          currentColor={currentColor}
          setCurrentColor={setCurrentColor}
          strokeWidth={strokeWidth}
          setStrokeWidth={setStrokeWidth}
          fontSize={fontSize}
          setFontSize={setFontSize}
          isBold={isBold}
          setIsBold={setIsBold}
          onUndo={() => {
            if (undoStack.length === 0) return;
            const previous = undoStack[undoStack.length - 1];
            setUndoStack((prev) => prev.slice(0, prev.length - 1));
            setRedoStack((prev) => [...prev, activePage.annotations || []]);
            handleSaveAnnotations(previous);
          }}
          onRedo={() => {
            if (redoStack.length === 0) return;
            const next = redoStack[redoStack.length - 1];
            setRedoStack((prev) => prev.slice(0, prev.length - 1));
            setUndoStack((prev) => [...prev, activePage.annotations || []]);
            handleSaveAnnotations(next);
          }}
          canUndo={undoStack.length > 0}
          canRedo={redoStack.length > 0}
          onClearPage={handleClearPage}
          isAutoSaved={isAutoSaved}
        />
        )}
      </div>

      {/* 4. Bottom Page Tabs Bar (مخفي في وضع التركيز) */}
      {!focusMode && (
        <div className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 px-3 py-1.5 flex items-center gap-1.5 overflow-x-auto text-xs font-bold select-none no-scrollbar">
          <span className="text-[11px] text-slate-400 font-semibold px-2 shrink-0">التنقل السريع بين الصفحات:</span>
          {currentDoc.pages.map((p, idx) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setCurrentPageIndex(idx)}
              className={`px-3 py-1 rounded-lg shrink-0 transition-all ${
                currentPageIndex === idx
                  ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              صفحة {p.pageNumber}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
