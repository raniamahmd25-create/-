import React, { useState, useMemo } from 'react';
import { 
  StudyDocument, 
  SubjectId, 
  DocumentType, 
  PublishFormat, 
  SUBJECTS, 
  DOC_TYPES 
} from '../../types';
import { 
  Search, 
  BookOpen, 
  FileText, 
  Image as ImageIcon, 
  Plus, 
  Trash2, 
  Star, 
  Edit3, 
  Sparkles,
  Layers,
  GraduationCap
} from 'lucide-react';
import { StudyReminder } from '../../types';
import { QuickReminderWidget } from '../reminders/QuickReminderWidget';

interface LibraryViewProps {
  documents: StudyDocument[];
  onOpenDocument: (doc: StudyDocument) => void;
  onOpenPublishModal: () => void;
  onDeleteDocument: (docId: string) => void;
  onToggleFavorite: (docId: string) => void;
  onLoadSampleExam: () => void;
  reminders?: StudyReminder[];
  onOpenRemindersModal?: () => void;
  onQuickToggleComplete?: (id: string) => void;
}

export const LibraryView: React.FC<LibraryViewProps> = ({
  documents,
  onOpenDocument,
  onOpenPublishModal,
  onDeleteDocument,
  onToggleFavorite,
  onLoadSampleExam,
  reminders = [],
  onOpenRemindersModal,
  onQuickToggleComplete,
}) => {
  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<SubjectId | 'all'>('all');
  const [selectedDocType, setSelectedDocType] = useState<DocumentType | 'all'>('all');
  const [selectedFormat, setSelectedFormat] = useState<PublishFormat | 'all'>('all');
  const [selectedDateFilter, setSelectedDateFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');
  const [sortBy, setSortBy] = useState<'latest' | 'oldest' | 'title'>('latest');

  // Filtered and Sorted Documents (Grade 5 focus, without user accounts)
  const filteredDocuments = useMemo(() => {
    return documents.filter((doc) => {
      // Keyword Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = doc.title.toLowerCase().includes(q);
        const matchesAuthor = doc.author?.toLowerCase().includes(q);
        const matchesDesc = doc.description?.toLowerCase().includes(q);
        const matchesTags = doc.tags?.some((t) => t.toLowerCase().includes(q));
        const matchesSubject = SUBJECTS.find((s) => s.id === doc.subject)?.nameAr.toLowerCase().includes(q);
        if (!matchesTitle && !matchesAuthor && !matchesDesc && !matchesTags && !matchesSubject) {
          return false;
        }
      }

      // Subject Filter
      if (selectedSubject !== 'all' && doc.subject !== selectedSubject) {
        return false;
      }

      // Document Type Filter
      if (selectedDocType !== 'all' && doc.docType !== selectedDocType) {
        return false;
      }

      // Format Filter (images or files)
      if (selectedFormat !== 'all' && doc.format !== selectedFormat) {
        return false;
      }

      // Date Filter
      if (selectedDateFilter !== 'all') {
        const docDate = new Date(doc.createdAt).getTime();
        const now = Date.now();
        const dayMs = 24 * 60 * 60 * 1000;
        if (selectedDateFilter === 'today' && now - docDate > dayMs) return false;
        if (selectedDateFilter === 'week' && now - docDate > 7 * dayMs) return false;
        if (selectedDateFilter === 'month' && now - docDate > 30 * dayMs) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'latest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sortBy === 'oldest') return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      if (sortBy === 'title') return a.title.localeCompare(b.title, 'ar');
      return 0;
    });
  }, [documents, searchQuery, selectedSubject, selectedDocType, selectedFormat, selectedDateFilter, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 font-['Cairo',sans-serif]">
      {/* 1. Header Banner - 5th Grade Dedicated Library (No account switching) */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-200 dark:border-slate-800 mb-8 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-slate-950 flex items-center justify-center font-black text-2xl shadow-sm">
            <GraduationCap className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-2.5 py-0.5 rounded-full border border-amber-200 dark:border-amber-800">
                المرحلة التعليمية المعتمدة
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                مكتبة الصف الخامس الابتدائي
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              جميع الكتب والملازم ونماذج الامتحانات والمراجعات المقررة لمنهج الصف الخامس الابتدائي مع القلم الإلكتروني الذكي
            </p>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onOpenPublishModal}
            className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 rounded-2xl text-xs sm:text-sm font-black shadow-md transition flex items-center gap-2"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>نشر كتاب أو ملزمة</span>
          </button>
        </div>
      </div>

      {/* Study Reminders & Daily Schedule Widget */}
      {onOpenRemindersModal && (
        <QuickReminderWidget
          reminders={reminders}
          onOpenRemindersModal={onOpenRemindersModal}
          onQuickToggleComplete={onQuickToggleComplete || (() => {})}
        />
      )}

      {/* 2. Advanced Search & Keyword Input */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-sm border border-slate-200 dark:border-slate-800 mb-8 space-y-4">
        <div className="relative">
          <Search className="absolute right-4 top-3.5 w-5 h-5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث بالاسم، المادة، المعلم، أو الكلمات المفتاحية (مثل: لغة عربية، كتاب الامتحان، رياضيات، علوم...)"
            className="w-full pr-12 pl-4 py-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 text-sm focus:ring-2 focus:ring-amber-500 focus:outline-none text-slate-900 dark:text-white"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute left-4 top-3.5 text-xs text-slate-400 hover:text-slate-600"
            >
              مسح
            </button>
          )}
        </div>

        {/* 3. Subject Chips Filter (عربي، دراسات، دين، Connect Plus، Connect، Science، Math) */}
        <div>
          <div className="text-xs font-extrabold text-slate-700 dark:text-slate-300 mb-2">
            تصفية بحسب مواد الصف الخامس الابتدائي:
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setSelectedSubject('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                selectedSubject === 'all'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              جميع المواد ({documents.length})
            </button>
            {SUBJECTS.map((s) => {
              const count = documents.filter((d) => d.subject === s.id).length;
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setSelectedSubject(s.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    selectedSubject === s.id
                      ? 'bg-amber-500 text-slate-950 shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <span>{s.nameAr}</span>
                  {count > 0 && (
                    <span className="text-[10px] px-1.5 py-0.2 bg-black/10 dark:bg-white/10 rounded-full font-mono">
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. Advanced Filter Selectors: Content Type, Format, Date, Sorting */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {/* Filter by Document Type (كتب، ملازم، مراجعات، مذكرات) */}
          <div>
            <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1">
              نوع المحتوى:
            </label>
            <select
              value={selectedDocType}
              onChange={(e) => setSelectedDocType(e.target.value as any)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs rounded-xl px-2.5 py-2 focus:outline-none font-medium"
            >
              <option value="all">الكل (كتب، ملازم، مراجعات، مذكرات)</option>
              {DOC_TYPES.map((dt) => (
                <option key={dt.id} value={dt.id}>
                  {dt.label}
                </option>
              ))}
            </select>
          </div>

          {/* Filter by Format (صور / ملفات) */}
          <div>
            <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1">
              صيغة الرفع:
            </label>
            <select
              value={selectedFormat}
              onChange={(e) => setSelectedFormat(e.target.value as any)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs rounded-xl px-2.5 py-2 focus:outline-none font-medium"
            >
              <option value="all">جميع الصيغ (ملفات وصور)</option>
              <option value="files">ملفات PDF فقط</option>
              <option value="images">صور ومسح ضوئي فقط</option>
            </select>
          </div>

          {/* Filter by Date */}
          <div>
            <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1">
              تاريخ الرفع والنشر:
            </label>
            <select
              value={selectedDateFilter}
              onChange={(e) => setSelectedDateFilter(e.target.value as any)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs rounded-xl px-2.5 py-2 focus:outline-none font-medium"
            >
              <option value="all">جميع التواريخ</option>
              <option value="today">المضافة اليوم</option>
              <option value="week">خلال هذا الأسبوع</option>
              <option value="month">خلال هذا الشهر</option>
            </select>
          </div>

          {/* Sort By */}
          <div>
            <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1">
              ترتيب النتائج:
            </label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs rounded-xl px-2.5 py-2 focus:outline-none font-medium"
            >
              <option value="latest">الأحدث إضافة أولاً</option>
              <option value="oldest">الأقدم أولاً</option>
              <option value="title">أبجدياً حسب العنوان</option>
            </select>
          </div>
        </div>
      </div>

      {/* 5. Documents Grid or Clean Initial Empty State */}
      {filteredDocuments.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-12 text-center border border-slate-200 dark:border-slate-800 shadow-sm max-w-2xl mx-auto">
          <div className="w-20 h-20 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto mb-4">
            <BookOpen className="w-10 h-10" />
          </div>
          <h3 className="text-xl font-black text-slate-900 dark:text-white mb-2">
            مكتبة الصف الخامس جاهزة لبدء مذاكرتك
          </h3>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-6 max-w-md mx-auto leading-relaxed">
            لم تقم بنشر أي مذكرات أو كتب حتى الآن. يمكنك رفع ملفاتك وصورك الخاصة، أو تجربة نموذج جاهز لاختبارات اللغة العربية للصف الخامس.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={onOpenPublishModal}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-extrabold text-sm shadow-lg transition flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              <span>نشر أول مذكرة أو كتاب الآن</span>
            </button>

            <button
              type="button"
              onClick={onLoadSampleExam}
              className="px-5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-sm transition flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>تجربة نموذج (كتاب الامتحان للصف الخامس)</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDocuments.map((doc) => {
            const subject = SUBJECTS.find((s) => s.id === doc.subject) || SUBJECTS[0];
            const docTypeInfo = DOC_TYPES.find((dt) => dt.id === doc.docType) || DOC_TYPES[0];
            const firstPage = doc.pages[0];

            return (
              <div
                key={doc.id}
                className="group relative bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-200 flex flex-col"
              >
                {/* Thumbnail Preview with Badges */}
                <div
                  onClick={() => onOpenDocument(doc)}
                  className="relative aspect-4/3 bg-slate-100 dark:bg-slate-950 overflow-hidden cursor-pointer"
                >
                  {firstPage ? (
                    <img
                      src={firstPage.imageUrl}
                      alt={doc.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-slate-400">
                      <BookOpen className="w-12 h-12" />
                    </div>
                  )}

                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />

                  {/* Top Badges */}
                  <div className="absolute top-3 right-3 flex items-center gap-1.5">
                    <span className={`text-[11px] px-2.5 py-1 rounded-full font-bold shadow-xs border ${subject.badgeColor}`}>
                      {doc.customSubjectName || subject.nameAr}
                    </span>
                  </div>

                  <div className="absolute top-3 left-3 flex items-center gap-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(doc.id);
                      }}
                      className="p-1.5 rounded-full bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm text-amber-500 hover:scale-110 transition shadow-sm"
                      title="المفضلة"
                    >
                      <Star className={`w-3.5 h-3.5 ${doc.isFavorite ? 'fill-current' : ''}`} />
                    </button>
                  </div>

                  {/* Bottom Stats inside Thumbnail */}
                  <div className="absolute bottom-3 right-3 left-3 flex items-center justify-between text-white text-xs font-bold pointer-events-none">
                    <span className="bg-black/50 backdrop-blur-sm px-2 py-0.5 rounded-lg flex items-center gap-1">
                      <Layers className="w-3.5 h-3.5" />
                      <span>{doc.pages.length} صفحات</span>
                    </span>
                    <span className="bg-black/50 backdrop-blur-sm px-2 py-0.5 rounded-lg">
                      {doc.format === 'files' ? 'ملف PDF' : 'صور'}
                    </span>
                  </div>
                </div>

                {/* Body Content */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mb-1.5">
                      <span className="font-bold text-amber-600 dark:text-amber-400">{docTypeInfo.label}</span>
                      <span>•</span>
                      <span>الصف الخامس الابتدائي</span>
                    </div>

                    <h3
                      onClick={() => onOpenDocument(doc)}
                      className="font-black text-base text-slate-900 dark:text-white mb-2 line-clamp-2 hover:text-amber-500 cursor-pointer transition-colors"
                      title={doc.title}
                    >
                      {doc.title}
                    </h3>

                    {doc.description && (
                      <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-3">
                        {doc.description}
                      </p>
                    )}
                  </div>

                  {/* Footer Action Buttons */}
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => onOpenDocument(doc)}
                      className="flex-1 py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-extrabold transition flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>المذاكرة وتعديل بالقلم</span>
                    </button>

                    {/* Immediate Delete Document Button (مسح فوري عند الضغط) */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteDocument(doc.id);
                      }}
                      className="px-3 py-2 rounded-xl text-rose-600 dark:text-rose-400 hover:text-white dark:hover:text-white bg-rose-50 hover:bg-rose-600 dark:bg-rose-950/60 dark:hover:bg-rose-600 transition flex items-center gap-1.5 text-xs font-bold shadow-2xs"
                      title="مسح هذه المذكرة فوراً"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>مسح</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
