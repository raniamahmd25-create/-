import React, { useState, useEffect } from 'react';
import { StudyDocument, StudyReminder } from './types';
import { StorageService } from './services/storage';
import { ReminderService } from './services/reminderService';
import { Navbar } from './components/layout/Navbar';
import { LibraryView } from './components/library/LibraryView';
import { DocumentViewer } from './components/viewer/DocumentViewer';
import { PublishModal } from './components/publish/PublishModal';
import { RemindersModal } from './components/reminders/RemindersModal';
import { StudyAlarmModal } from './components/reminders/StudyAlarmModal';

export default function App() {
  // 1. Dark Mode State
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('qalami_theme_mode');
    if (saved) return saved === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('qalami_theme_mode', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('qalami_theme_mode', 'light');
    }
  }, [darkMode]);

  const toggleDarkMode = () => setDarkMode((prev) => !prev);

  // 2. Documents State (starts empty as requested: "وخلي الموقع مفهوش اي مزكرات")
  const [documents, setDocuments] = useState<StudyDocument[]>(() => StorageService.getDocuments());

  // 3. Google Tabs / Open Documents State
  const [openDocuments, setOpenDocuments] = useState<StudyDocument[]>([]);
  const [activeDocId, setActiveDocId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'library' | 'viewer'>('library');

  // 4. Publishing Modal
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);

  // 5. Study Reminders & Alarms State
  const [reminders, setReminders] = useState<StudyReminder[]>(() => ReminderService.getReminders());
  const [isRemindersModalOpen, setIsRemindersModalOpen] = useState(false);
  const [preselectedDocForReminder, setPreselectedDocForReminder] = useState<StudyDocument | null>(null);
  const [activeAlarmReminder, setActiveAlarmReminder] = useState<StudyReminder | null>(null);

  // Refresh reminders from storage
  const refreshReminders = () => {
    setReminders(ReminderService.getReminders());
  };

  // Background timer to check for due study alarms
  useEffect(() => {
    const checkAlarms = () => {
      const dueReminders = ReminderService.checkDueReminders();
      if (dueReminders.length > 0) {
        const topDue = dueReminders[0];
        // Trigger alert tone & browser notification
        ReminderService.triggerNotification(topDue);
        // Display in-app alarm modal
        setActiveAlarmReminder(topDue);
        refreshReminders();
      }
    };

    // Check immediately and every 10 seconds
    checkAlarms();
    const interval = setInterval(checkAlarms, 10000);
    return () => clearInterval(interval);
  }, []);

  // Refresh docs from storage
  const refreshDocuments = () => {
    setDocuments(StorageService.getDocuments());
  };

  // Open Document in Viewer with Google Tabs
  const handleOpenDocument = (doc: StudyDocument) => {
    if (!openDocuments.some((d) => d.id === doc.id)) {
      setOpenDocuments((prev) => [...prev, doc]);
    }
    setActiveDocId(doc.id);
    setViewMode('viewer');
  };

  // Close Tab
  const handleCloseDocumentTab = (docId: string) => {
    const remaining = openDocuments.filter((d) => d.id !== docId);
    setOpenDocuments(remaining);

    if (activeDocId === docId) {
      if (remaining.length > 0) {
        setActiveDocId(remaining[remaining.length - 1].id);
      } else {
        setActiveDocId(null);
        setViewMode('library');
      }
    }
  };

  // Select Tab
  // Toast Notification State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 2800);
  };

  // Select Tab
  const handleSelectDocumentTab = (docId: string) => {
    setActiveDocId(docId);
  };

  // Immediate Delete Document (مسح فوري دون انتظار)
  const handleDeleteDocument = (docId: string) => {
    StorageService.deleteDocument(docId);
    setDocuments((prev) => prev.filter((d) => d.id !== docId));
    handleCloseDocumentTab(docId);
    showToast('تم مسح المذكرة فوراً من مكتبتك 🗑️');
  };

  // Toggle Favorite
  const handleToggleFavorite = (docId: string) => {
    StorageService.toggleFavorite(docId);
    refreshDocuments();
  };

  // Document Created Callback
  const handleDocumentCreated = (newDoc: StudyDocument) => {
    refreshDocuments();
    handleOpenDocument(newDoc);
    showToast('تم نشر المذكرة بنجاح في مكتبة الصف الخامس ✨');
  };

  // Load Sample Exam (5th Grade Arabic - Al-Emtehan)
  const handleLoadSampleExam = () => {
    const sample = StorageService.createSampleArabicExam('grade_5_student');
    StorageService.saveDocument(sample);
    refreshDocuments();
    handleOpenDocument(sample);
    showToast('تم تحميل نموذج اختبارات كتاب الامتحان للصف الخامس بنجاح 📚');
  };

  // Reminder Handlers
  const handleOpenRemindersModal = () => {
    setPreselectedDocForReminder(null);
    setIsRemindersModalOpen(true);
  };

  const handleOpenReminderForDoc = (doc: StudyDocument) => {
    setPreselectedDocForReminder(doc);
    setIsRemindersModalOpen(true);
  };

  const handleSnoozeReminder = (reminderId: string, minutes: number = 5) => {
    ReminderService.snoozeReminder(reminderId, minutes);
    setActiveAlarmReminder(null);
    refreshReminders();
    showToast(`تم تأجيل تنبيه المذاكرة ${minutes} دقائق ⏱️`);
  };

  const handleCompleteReminder = (reminderId: string) => {
    ReminderService.toggleCompleted(reminderId);
    setActiveAlarmReminder(null);
    refreshReminders();
    showToast('أحسنت يا بطل! تم إنجاز مراجعة المادة بنجاح 🌟');
  };

  const handleQuickToggleReminderComplete = (reminderId: string) => {
    const isDone = ReminderService.toggleCompleted(reminderId);
    refreshReminders();
    if (isDone) {
      showToast('تم إنجاز المراجعة بنجاح! أحسنت 🌟');
    }
  };

  const handleOpenDocById = (docId: string) => {
    const doc = documents.find((d) => d.id === docId);
    if (doc) {
      handleOpenDocument(doc);
    }
  };

  const activeRemindersCount = reminders.filter((r) => r.isActive && !r.isCompleted).length;

  // Currently Active Document in Viewer
  const activeDocument = openDocuments.find((d) => d.id === activeDocId) || documents.find((d) => d.id === activeDocId);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-['Cairo',sans-serif]">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-slate-900 dark:bg-amber-400 text-white dark:text-slate-950 px-4 py-2 rounded-2xl shadow-xl text-xs font-black flex items-center gap-2 border border-slate-700 dark:border-amber-500 animate-in fade-in slide-in-from-top duration-200">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Show Navbar when in library mode */}
      {viewMode === 'library' && (
        <Navbar
          darkMode={darkMode}
          onToggleDarkMode={toggleDarkMode}
          onOpenPublishModal={() => setIsPublishModalOpen(true)}
          onOpenRemindersModal={handleOpenRemindersModal}
          totalDocsCount={documents.length}
          activeRemindersCount={activeRemindersCount}
        />
      )}

      {/* Main Content Router */}
      <main className="flex-1">
        {viewMode === 'viewer' && activeDocument ? (
          <DocumentViewer
            initialDocument={activeDocument}
            openDocuments={openDocuments}
            activeDocId={activeDocId!}
            onSelectDocument={handleSelectDocumentTab}
            onCloseDocument={handleCloseDocumentTab}
            onBackToLibrary={() => setViewMode('library')}
            onOpenPublishModal={() => setIsPublishModalOpen(true)}
            onDeleteDocument={handleDeleteDocument}
            darkMode={darkMode}
            onToggleDarkMode={toggleDarkMode}
            onOpenReminderForDoc={handleOpenReminderForDoc}
          />
        ) : (
          <LibraryView
            documents={documents}
            onOpenDocument={handleOpenDocument}
            onOpenPublishModal={() => setIsPublishModalOpen(true)}
            onDeleteDocument={handleDeleteDocument}
            onToggleFavorite={handleToggleFavorite}
            onLoadSampleExam={handleLoadSampleExam}
            reminders={reminders}
            onOpenRemindersModal={handleOpenRemindersModal}
            onQuickToggleComplete={handleQuickToggleReminderComplete}
          />
        )}
      </main>

      {/* Publish Modal */}
      <PublishModal
        isOpen={isPublishModalOpen}
        onClose={() => setIsPublishModalOpen(false)}
        onDocumentCreated={handleDocumentCreated}
      />

      {/* Study Reminders Management Modal */}
      <RemindersModal
        isOpen={isRemindersModalOpen}
        onClose={() => {
          setIsRemindersModalOpen(false);
          setPreselectedDocForReminder(null);
        }}
        documents={documents}
        onOpenDocument={handleOpenDocument}
        preselectedDoc={preselectedDocForReminder}
        onReminderChanged={refreshReminders}
      />

      {/* In-App Study Alarm Modal (When a reminder hits) */}
      <StudyAlarmModal
        reminder={activeAlarmReminder}
        onClose={() => setActiveAlarmReminder(null)}
        onSnooze={handleSnoozeReminder}
        onComplete={handleCompleteReminder}
        onOpenDocument={handleOpenDocById}
      />
    </div>
  );
}
