export type SubjectId = 
  | 'arabic' 
  | 'social_studies' 
  | 'islamic_studies' 
  | 'connect_plus' 
  | 'connect' 
  | 'science' 
  | 'math' 
  | 'ict' 
  | 'french' 
  | 'custom';

export type DocumentType = 'book' | 'booklet' | 'revision' | 'notes';
export type PublishFormat = 'images' | 'files';

export interface SubjectInfo {
  id: SubjectId;
  nameAr: string;
  nameEn: string;
  badgeColor: string;
  bgLight: string;
  bgDark: string;
  iconName: string;
}

export const SUBJECTS: SubjectInfo[] = [
  { id: 'arabic', nameAr: 'اللغة العربية', nameEn: 'Arabic', badgeColor: 'text-emerald-700 bg-emerald-50 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800', bgLight: 'bg-emerald-500', bgDark: 'bg-emerald-600', iconName: 'BookOpen' },
  { id: 'social_studies', nameAr: 'الدراسات الاجتماعية', nameEn: 'Social Studies', badgeColor: 'text-amber-700 bg-amber-50 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800', bgLight: 'bg-amber-500', bgDark: 'bg-amber-600', iconName: 'Globe' },
  { id: 'islamic_studies', nameAr: 'التربية الدينية', nameEn: 'Islamic Studies', badgeColor: 'text-teal-700 bg-teal-50 border-teal-200 dark:bg-teal-950/60 dark:text-teal-300 dark:border-teal-800', bgLight: 'bg-teal-500', bgDark: 'bg-teal-600', iconName: 'Moon' },
  { id: 'connect_plus', nameAr: 'Connect Plus', nameEn: 'Connect Plus', badgeColor: 'text-blue-700 bg-blue-50 border-blue-200 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800', bgLight: 'bg-blue-500', bgDark: 'bg-blue-600', iconName: 'Sparkles' },
  { id: 'connect', nameAr: 'Connect', nameEn: 'Connect', badgeColor: 'text-cyan-700 bg-cyan-50 border-cyan-200 dark:bg-cyan-950/60 dark:text-cyan-300 dark:border-cyan-800', bgLight: 'bg-cyan-500', bgDark: 'bg-cyan-600', iconName: 'Languages' },
  { id: 'science', nameAr: 'Science / العلوم', nameEn: 'Science', badgeColor: 'text-purple-700 bg-purple-50 border-purple-200 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-800', bgLight: 'bg-purple-500', bgDark: 'bg-purple-600', iconName: 'FlaskConical' },
  { id: 'math', nameAr: 'Math / الرياضيات', nameEn: 'Math', badgeColor: 'text-rose-700 bg-rose-50 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800', bgLight: 'bg-rose-500', bgDark: 'bg-rose-600', iconName: 'Calculator' },
  { id: 'ict', nameAr: 'تكنولوجيا المعلومات ICT', nameEn: 'ICT', badgeColor: 'text-indigo-700 bg-indigo-50 border-indigo-200 dark:bg-indigo-950/60 dark:text-indigo-300 dark:border-indigo-800', bgLight: 'bg-indigo-500', bgDark: 'bg-indigo-600', iconName: 'Laptop' },
  { id: 'custom', nameAr: 'مادة أخرى', nameEn: 'Other Subject', badgeColor: 'text-slate-700 bg-slate-100 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700', bgLight: 'bg-slate-600', bgDark: 'bg-slate-700', iconName: 'Folder' },
];

export const DOC_TYPES: { id: DocumentType; label: string; description: string; icon: string }[] = [
  { id: 'booklet', label: 'ملزمة دراسية', description: 'شرح مبسط وتدريبات وتمارين', icon: 'FileText' },
  { id: 'book', label: 'كتاب كامل', description: 'كتاب مدرسي أو كتاب خارجي', icon: 'Book' },
  { id: 'revision', label: 'نماذج اختبارات ومراجعة', description: 'اختبارات شهرية، نماذج إجابات، مراجعات ليلة الامتحان', icon: 'CheckSquare' },
  { id: 'notes', label: 'مذكرات وتلخيصات', description: 'مذكرات سريعة وقواعد وملاحظات هامة', icon: 'PenTool' },
];

export interface Point {
  x: number;
  y: number;
}

export type ToolMode = 
  | 'pen' 
  | 'highlighter' 
  | 'eraser' 
  | 'text' 
  | 'rect' 
  | 'line' 
  | 'arrow' 
  | 'circle' 
  | 'cursor';

export interface AnnotationItem {
  id: string;
  type: ToolMode;
  color: string;
  strokeWidth: number;
  opacity?: number;
  points?: Point[];
  startPoint?: Point;
  endPoint?: Point;
  text?: string;
  fontSize?: number;
  fontFamily?: string;
  isBold?: boolean;
  box?: {
    x: number;
    y: number;
    width?: number;
    height?: number;
  };
}

export interface DocumentPage {
  id: string;
  pageNumber: number;
  imageUrl: string;
  annotations: AnnotationItem[];
  notes?: string;
  lastEdited?: number;
}

export interface StudyDocument {
  id: string;
  title: string;
  subject: SubjectId;
  customSubjectName?: string;
  docType: DocumentType;
  format: PublishFormat;
  grade: string;
  term: 'term1' | 'term2' | 'full_year';
  author: string;
  description: string;
  tags: string[];
  pages: DocumentPage[];
  createdAt: string;
  updatedAt: string;
  userId: string;
  isFavorite?: boolean;
  bookmarks?: number[];
}

export interface UserProfile {
  id: string;
  name: string;
  role: 'student' | 'teacher' | 'parent';
  grade?: string;
  avatarColor: string;
}

export type ReminderRepeatType = 'once' | 'daily' | 'weekdays' | 'custom';
export type ReminderPriority = 'normal' | 'medium' | 'high';

export interface StudyReminder {
  id: string;
  subjectId: SubjectId;
  customSubjectName?: string;
  title: string;
  targetDate: string; // YYYY-MM-DD
  targetTime: string; // HH:MM (24h)
  repeatType: ReminderRepeatType;
  repeatDays?: number[]; // [0,1,2,3,4,5,6] (0 = Sunday, 1 = Monday, etc.)
  notes?: string;
  linkedDocId?: string;
  linkedDocTitle?: string;
  priority: ReminderPriority;
  isActive: boolean;
  isCompleted: boolean;
  lastTriggered?: string; // YYYY-MM-DDTHH:mm
  createdAt: string;
}

export const SUBJECT_PRESET_TASKS: Record<SubjectId, string[]> = {
  arabic: [
    'مراجعة القواعد النحوية والإعراب',
    'حل تدريبات درس القراءة والنصوص',
    'كتابة موضوع التعبير والخط العربي',
    'مراجعة الإملاء والظواهر اللغوية',
  ],
  math: [
    'مراجعة ضرب وقسمة الكسور العشرية',
    'حل تدريبات سلاح التلميذ والأضواء',
    'مراجعة الهندسة وحساب المساحات والمحيط',
    'حل اختبار الفصل والمسائل اللفظية',
  ],
  science: [
    'مراجعة أجهزة الجسم والتكيف في الكائنات الحية',
    'مذاكرة المفاهيم العلمية والمصطلحات',
    'حل أنشطة كتاب العلوم وتجارب المنهج',
    'مراجعة اختبار المفهوم للوحدة الأولى',
  ],
  social_studies: [
    'مراجعة خريطة مصر التفاعلية والتضاريس',
    'مذاكرة شخصيات مصرية مؤثرة عبر التاريخ',
    'حل أسئلة المحافظات ونماذج الامتحانات',
    'مراجعة الموارد الطبيعية والبيئية في مصر',
  ],
  connect_plus: [
    'Connect Plus: Review Unit Vocabulary & Phonics',
    'Connect Plus: Grammar exercises & writing tasks',
    'Connect Plus: Practice reading comprehension',
  ],
  connect: [
    'Connect: Review English Vocabulary & Spelling',
    'Connect: Solve workbook exercises',
    'Connect: Practice speaking and dialogue',
  ],
  islamic_studies: [
    'مراجعة السور القرآنية المقررة وأحكام التلاوة',
    'حفظ ومذاكرة الأحاديث النبوية الشريفة',
    'مراجعة سيرة النبي صلى الله عليه وسلم والصحابة',
  ],
  ict: [
    'مراجعة أدوات التكنولوجيا والاتصالات الرقمية',
    'مذاكرة درس الأمان الرقمي وكلمات المرور',
    'حل تدريبات كتاب تكنولوجيا المعلومات والاتصالات',
  ],
  french: [
    'Révision du vocabulaire et dialogues',
    'Exercices de grammaire et conjugaison',
  ],
  custom: [
    'مراجعة عامة وحل تدريبات',
    'تلخيص الدرس وكتابة الملاحظات',
    'حل اختبار تقييم ذاتي',
  ],
};
