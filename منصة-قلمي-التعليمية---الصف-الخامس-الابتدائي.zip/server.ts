import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Body parser with 25MB limit to allow image dataURL from canvas/pages
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Initialize GoogleGenAI SDK
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// AI Tutor Chat / Study Assistant endpoint
app.post('/api/ai-tutor', async (req, res) => {
  try {
    const { 
      question, 
      docTitle, 
      subjectName, 
      pageNumber, 
      pageImage,
      chatHistory = [] 
    } = req.body;

    if (!question || !question.trim()) {
      return res.status(400).json({ error: 'يرجى كتابة سؤالك' });
    }

    const systemInstruction = `أنت «المعلم الذكي» لطلاب الصف الخامس الابتدائي في مصر.
مهمتك:
- مساعدة الطالب في فهم دروس ومذكرات الصف الخامس (اللغة العربية، الدراسات الاجتماعية، التربية الدينية، العلوم Science، الرياضيات Math، Connect، Connect Plus، وتكنولوجيا المعلومات ICT).
- تقديم إجابات واضحة، تعليمية، ومبسطة تناسب سن وفهم طالب الصف الخامس.
- تشجيع الطالب وتقديم أمثلة واقعية.
- عند شرح أسئلة الامتحانات أو النحو أو حل المسائل، اشرح خطوة بخطوة مع التعليل.
- إذا أرسل الطالب صورة لصفحة المذكرة أو الامتحان، اقرأ السؤال منها بدقة وساعده في حله وفهمه.
- التحدث باللغة العربية الفصحى البسيطة والمحببة للأطفال.`;

    // Construct prompt contents
    const contents: any[] = [];

    // Context metadata
    let contextText = `[سياق المذاكرة الحالي]\nالمذكرة/الكتاب: ${docTitle || 'مذكرة الصف الخامس'}\nالمادة: ${subjectName || 'عام'}\nرقم الصفحة المعروضة: ${pageNumber || 1}\n\n`;

    // If chat history is provided, include brief history for conversational continuity
    if (Array.isArray(chatHistory) && chatHistory.length > 0) {
      contextText += `[سياق المحادثة السابقة]\n`;
      chatHistory.slice(-4).forEach((msg: any) => {
        contextText += `${msg.role === 'user' ? 'الطالب' : 'المعلم'}: ${msg.text}\n`;
      });
      contextText += `\n`;
    }

    contextText += `سؤال الطالب الحالي: ${question}`;

    // If an image of the current page is provided, send it as multimodal part
    if (pageImage && typeof pageImage === 'string' && pageImage.startsWith('data:image/')) {
      const match = pageImage.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
      if (match) {
        const mimeType = match[1];
        const base64Data = match[2];

        contents.push({
          parts: [
            {
              inlineData: {
                mimeType,
                data: base64Data,
              },
            },
            {
              text: contextText,
            },
          ],
        });
      } else {
        contents.push({ text: contextText });
      }
    } else {
      contents.push({ text: contextText });
    }

    // Call gemini-3.8-flash model
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: contents.length === 1 && typeof contents[0].text === 'string' ? contents[0].text : contents[0],
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const reply = response.text || 'عذراً، لم أتمكن من استخراج الإجابة. يرجى تكرار السؤال أو صياغته بشكل أوضح.';

    return res.json({ reply });
  } catch (error: any) {
    console.error('AI Tutor API error:', error);
    return res.status(500).json({ 
      error: 'حدث خطأ أثناء التواصل مع المعلم الذكي. يرجى التأكد من كتابة السؤال والمحاولة مرة أخرى.',
      details: error?.message || 'Server error'
    });
  }
});

// Vite Middleware for development
if (process.env.NODE_ENV !== 'production') {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  // Serve static files in production
  app.use(express.static(path.join(__dirname, 'dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
